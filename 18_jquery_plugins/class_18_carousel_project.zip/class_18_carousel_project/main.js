$('.your-class').slick({
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 3,
    dots: true,
    accessibility: false,
    autoplay: true,
    autoplaySpeed: 1000,
    arrows: true
});

$.goup({
    alwaysVisible: true,
    containerColor: '#FF0000'
});

var s = skrollr.init();

$('#sticky-header-container').stick_in_parent();
$('#sticky-header-container nav').stick_in_parent();