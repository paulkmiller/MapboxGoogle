
  /* Turn the following statements into javascript statements and functions. These are not in context to any html or css.


    1.  Write a statement that makes the background of a div with the id colorMe <div id="colorMe"> red.

    2.  Write a function that logs in the console 7 as a string. Take the same string and make it a number - also log the result. Finally, add them together and log the result.

    3.  Write a function that returns the string "foo".

    4.  Write a function that logs to the console "Today is" and a day of the week that is passed to your function in an argument (dayName). Call your function and make it run. 

    5.  Write a function that takes two number arguments (num1 and num2). The function should add those 2 numbers and return the result

    6.  Write a function that takes two number arguments (num1 and num2). The function should multiply those 2 numbers and return the result

    BONUS: Write a function that takes one argument (num). Make the function return true if that number is even and return false if it's odd.

  
    
    If you finish all of the above, work on your final project!

   */

