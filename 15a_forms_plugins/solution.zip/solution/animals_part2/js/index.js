$(document).ready(function(){
  $('.carousel').slick();
});