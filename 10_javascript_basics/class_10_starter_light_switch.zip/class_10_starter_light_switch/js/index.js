var lights = 'on';

function switchLights() {

}

document.getElementById('light_switch').onclick = switchLights;